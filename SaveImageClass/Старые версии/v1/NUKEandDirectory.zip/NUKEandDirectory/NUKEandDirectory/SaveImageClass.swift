//
//  SaveImageClass.swift
//  NUKEandDirectory
//
//  Created by Username on 06.06.2019.
//  Copyright © 2019 Username. All rights reserved.
//

import UIKit
import Nuke

class SaveImageClass: NSObject {

    //сохранение изображения по ключу

    private static func saveImage(image: UIImage, key: String) {
        guard let fileURL = SaveImageClass.getFileUrl(name: key) else {
            return
        }

        guard let data = image.pngData() else {
            return
        }

        if FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                try FileManager.default.removeItem(atPath: fileURL.path)
                print("Removed old image")
            } catch let removeError {
                print("couldn't remove file at path", removeError)
            }
        }
        do {
            try data.write(to: fileURL)
        } catch let error {
            print("error saving file with error", error)
        }
    }

    //получени ссылки на изображение в директории

    private static func getFileUrl(name: String) -> URL? {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory,
                                                                in: .userDomainMask).first else {
                                                                    return nil
        }

        return documentsDirectory.appendingPathComponent(name)
    }

    //получение самого изображения

    private static func loadImageFromDiskWith(name: String) -> UIImage? {
        if let dirPath = SaveImageClass.getPaths() {
            let imageUrl = URL(fileURLWithPath: dirPath).appendingPathComponent(name)
            let image = UIImage(contentsOfFile: imageUrl.path)
            return image
        }

        return nil
    }

    private static func getPaths() -> String? {
        let documentDirectory = FileManager.SearchPathDirectory.documentDirectory

        let userDomainMask = FileManager.SearchPathDomainMask.userDomainMask
        return NSSearchPathForDirectoriesInDomains(documentDirectory, userDomainMask, true).first
    }

    //сохранение/получение изображения

    static func updateUI(imageURL: URL, imageView: UIImageView, completion:@escaping() -> Void) {
        let keySave = imageURL.keyURL

        if let image = SaveImageClass.loadImageFromDiskWith(name: keySave) {
            imageView.image = image
            completion()
        } else {
            Nuke.loadImage(with: imageURL,
                           options: ImageLoadingOptions.shared,
                           into: imageView,
                           progress: nil) { (loadingImage, error) in
                            if let image = loadingImage?.image {
                                DispatchQueue.global(qos: .userInitiated).async {
                                    SaveImageClass.saveImage(image: image, key: keySave)
                                }
                                completion()
                            } else if let error = error {
                                print(error)
                            }
            }
        }
    }

    //удаление файлов записанных 3 дня назад

    static func removeFrieDayObject() {
        var arrayKeys: [String] = []

        guard let dirPath = SaveImageClass.getPaths() else {
            return
        }

        do {
            arrayKeys = try FileManager.default.contentsOfDirectory(atPath: dirPath)
        } catch let removeError {
            print(removeError)
            return
        }

        for key in arrayKeys {
            if let fileURL = SaveImageClass.getFileUrl(name: key) {
                if let date = URL(fileURLWithPath: dirPath).appendingPathComponent(key).creationDate {
                    if date.secondsHavePassed(3 * 24 * 3_600) && !key.contains("CoreData") { //проверка нужна для того что бы не удалить кор дату
                        do {
                            try FileManager.default.removeItem(atPath: fileURL.path)
                            print("удалили старый файл \(key)")
                        } catch let removeError {
                            print("ошибка удаления", removeError)
                        }
                    }
                }
            }
        }
    }


}

extension URL{
    var keyURL: String {
        let str = self.absoluteString
        return str.removeCharacters(from: "/:.")
    }

    // методы ниже нужны для получения/извлечения/проверки есть ли такое изображение в директории
    var attributes: [FileAttributeKey: Any]? {
        do {
            return try FileManager.default.attributesOfItem(atPath: path)
        } catch let error as NSError {
            print("FileAttribute error: \(error)")
        }
        return nil
    }

    var fileSize: UInt64 {
        return attributes?[.size] as? UInt64 ?? UInt64(0)
    }

    var fileSizeString: String {
        return ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file)
    }

    var creationDate: Date? {
        return attributes?[.creationDate] as? Date
    }
}

extension String {

    func removeCharacters(from forbiddenChars: CharacterSet) -> String {
        let passed = self.unicodeScalars.filter { !forbiddenChars.contains($0) }
        return String(String.UnicodeScalarView(passed))
    }

    func removeCharacters(from: String) -> String {
        return removeCharacters(from: CharacterSet(charactersIn: from))
    }
}

extension Date {
    func secondsHavePassed(_ seconds: Int) -> Bool { //проверяем, прошло ли данное количество секунд
        let delta = -1 * seconds
        let frieDaysHave = Date(timeIntervalSinceNow: TimeInterval(delta))
        let deltaTime = Calendar.current.compare(frieDaysHave, to: self, toGranularity: .second)

        if deltaTime.rawValue == -1 {
            return false // не прошло 3е суток
        } else {
            return true
        }
    }
}
