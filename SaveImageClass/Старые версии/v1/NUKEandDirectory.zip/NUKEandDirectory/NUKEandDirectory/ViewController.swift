//
//  ViewController.swift
//  NUKEandDirectory
//
//  Created by Username on 05.06.2019.
//  Copyright © 2019 Username. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {


    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.register(UINib(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "Cell")
    }


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayURL.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CustomTableViewCell
        cell.imageURL = self.arrayURL[indexPath.row]
        return cell
    }

}

extension ViewController{
    var arrayURL: [URL?] {
        let array = [
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/5/6/2/10439265.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/6/6/2/10439266.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/7/6/2/10439267.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/8/6/2/10439268.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/9/6/2/10439269.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/0/7/2/10439270.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/2/7/2/10439272.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/5/7/2/10439275.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/7/7/2/10439277.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/8/7/2/10439278.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/1/8/2/10439281.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/2/8/2/10439282.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/6/8/2/10439286.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/9/8/2/10439289.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/1/9/2/10439291.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/3/9/2/10439293.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/6/9/2/10439296.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/9/9/2/10439299.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/1/0/3/10439301.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/3/0/3/10439303.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/5/0/3/10439305.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/9/0/3/10439309.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/1/1/3/10439311.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/3/1/3/10439313.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/5/1/3/10439315.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/6/1/3/10439316.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/6/1/3/10439316.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/1/2/3/10439321.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/4/2/3/10439324.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/4/3/3/10439334.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/7/3/3/10439337.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/0/4/3/10439340.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/6/4/3/10439346.jpg"),
            URL(string: "https://s00.yaplakal.com/pics/pics_preview/7/4/3/10439347.jpg")
        ]

        return array
    }
}

