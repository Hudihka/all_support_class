//
//  CustomTableViewCell.swift
//  NUKEandDirectory
//
//  Created by Username on 05.06.2019.
//  Copyright © 2019 Username. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var spiner: UIActivityIndicatorView!

    var imageURL: URL? {
        didSet {
            myImage?.image = nil
            if let url = imageURL{
                SaveImageClass.updateUI(imageURL: url, imageView: myImage) {
                    self.spiner.stopAnimating()
                }
            }
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
